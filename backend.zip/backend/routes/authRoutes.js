const express = require("express");
const router = express.Router();
const { registerUser } = require("../controllers/authController");
const multer = require("multer");

const upload = require("../middleware/multer"); // Store uploaded files here

// Signup route
router.post(
  "/signup",
  upload.single("license"), // Expecting a single file upload field named 'license'
  registerUser
);
  

module.exports = router;