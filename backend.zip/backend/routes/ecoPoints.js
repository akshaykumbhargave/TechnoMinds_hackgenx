const express = require('express');
const router = express.Router();
const EcoUser = require('../models/EcoUser'); // Your Mongoose model

// Update points
router.post('/add', async (req, res) => {
  const { userId, points } = req.body;

  try {
    let user = await EcoUser.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.ecoPoints += points;
    await user.save();

    res.json({ message: 'Points updated', totalPoints: user.ecoPoints });
  } catch (err) {
    res.status(500).json({ message: 'Error updating points' });
  }
});

module.exports = router;
