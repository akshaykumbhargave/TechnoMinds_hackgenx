const express = require("express");
const router = express.Router();

// Simple rule-based replies
const responses = {
  hello: "Hello there! 👋",
  help: "How can I assist you?",
  price: "Our prices depend on the item. Please specify the product.",
  bye: "Goodbye! Have a nice day 😊",
};

router.post("/", (req, res) => {
  const userMsg = req.body.message.toLowerCase();

  let reply = "Sorry, I didn't understand that.";

  for (const keyword in responses) {
    if (userMsg.includes(keyword)) {
      reply = responses[keyword];
      break;
    }
  }

  res.json({ reply });
});

module.exports = router;
