import React from "react";
import { useNavigate } from "react-router-dom";
import "./DiagnosisResult.css";

function DiagnosisResult({ onDecision }) {
  const navigate = useNavigate();

  const handleDecision = (decisionType) => {
    try {
      if (typeof onDecision === 'function') {
        onDecision(decisionType);
        return;
      }
      
      const routes = {
        repair: "/location", // Goes to the location selection page
        disposal: "/disposalLocation"
      };
      
      if (routes[decisionType]) {
        navigate(routes[decisionType]);
      } else {
        console.error("Invalid decision type:", decisionType);
        navigate("/");
      }
    } catch (error) {
      console.error("Error handling decision:", error);
      navigate("/");
    }
  };

  return (
    <div className="diagnosis-result-container">
      <div className="diagnosis-header">
        <h2>Your Eco-Friendly Options Await</h2>
        <p className="diagnosis-description">
          What do you want to choose for your device?
        </p>
      </div>
      
      <div className="decision-options">
        <button 
          className="decision-button repair-option"
          onClick={() => handleDecision("repair")}
          aria-label="Choose repair option"
        >
          <span className="button-icon">🛠️</span>
          <span className="button-text">Repair</span>
          <span className="button-subtext">Find nearest repair center</span>
        </button>
        
        <button 
          className="decision-button disposal-option"
          onClick={() => handleDecision("disposal")}
          aria-label="Choose disposal option"
        >
          <span className="button-icon">♻️</span>
          <span className="button-text">Dispose</span>
          <span className="button-subtext">Recycle properly</span>
        </button>
      </div>
    </div>
  );
}

export default DiagnosisResult;