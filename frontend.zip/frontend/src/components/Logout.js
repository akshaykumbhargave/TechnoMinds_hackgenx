import React from 'react';

const Logout = () => {
  return <h2>You have been logged out</h2>;
};

export default Logout;
