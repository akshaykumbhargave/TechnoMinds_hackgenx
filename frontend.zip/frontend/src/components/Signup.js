import React, { useState } from "react";
import axios from "../api/axios";
 // Your custom axios instance
import { useNavigate } from "react-router-dom";

const SignUp = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "",
    address: "",
    license: null,
  });

  const handleChange = (e) => {
    if (e.target.name === "license") {
      setFormData({ ...formData, license: e.target.files[0] });
    } else {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const data = new FormData();
      data.append("name", formData.name);
      data.append("email", formData.email);
      data.append("password", formData.password);
      data.append("role", formData.role);
      data.append("address", formData.address);
      if (formData.license) {
        data.append("license", formData.license);
      }

      const response = await axios.post("/auth/signup", data, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      alert("✅ Registered successfully!");
      navigate("/login");
    } catch (error) {
      console.error("Registration Error:", error.response?.data || error.message);
      alert("❌ Registration failed: " + (error.response?.data?.message || error.message));
    }
  };

  return (
    <div className="signup-form">
      <h2>Register</h2>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <input type="text" name="name" placeholder="Name" onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
        <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
        <input type="text" name="role" placeholder="Role (e.g. user/admin)" onChange={handleChange} required />
        <input type="text" name="address" placeholder="Address" onChange={handleChange} required />
        <input type="file" name="license" accept="image/*" onChange={handleChange} />
        <button type="submit">Sign Up</button>
      </form>
    </div>
  );
};

export default SignUp;
