import React from "react";
import { useNavigate, useLocation } from "react-router-dom";


const NGOInitiative = () => {
  const navigate = useNavigate();
      const location = useLocation();
const handleBackClick = () => {
  navigate(-1);
};
  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={styles.heading}>NGO Initiative</h2>
        <div style={styles.section}>
          <h3>Top NGOs Supporting E-Waste Management in Pune</h3>
          <ul style={styles.list}>
            <li>
              <strong>Janwani</strong> – Supported by MCCIA, Janwani works on e-waste collection and segregation in Pune.
              <br />
              <a href="https://www.janwanipune.org" target="_blank" rel="noopener noreferrer">
                Visit Website
              </a>
            </li>
            <li>
              <strong>Poornam Ecovision Foundation</strong> – Runs the "E-Yantran" project for door-to-door e-waste pickup.
              <br />
              <a href="https://poornamecovision.org/projects/e-yantran-e-waste-n-plastic-collection" target="_blank" rel="noopener noreferrer">
                Visit Website
              </a>
            </li>
            <li>
              <strong>SWaCH</strong> – A waste-pickers' co-op offering inclusive e-waste collection and recycling services.
              <br />
              <a href="https://swachcoop.com" target="_blank" rel="noopener noreferrer">
                Visit Website
              </a>
            </li>
            <li>
              <strong>Adar Poonawalla Clean City Initiative</strong> – Partners with PMC for QR-code based e-waste collection.
              <br />
              <a href="https://www.adarpcleancity.com/ewaste.html" target="_blank" rel="noopener noreferrer">
                Visit Website
              </a>
            </li>
            <li>
              <strong>Recycle India Foundation</strong> – A national NGO raising awareness on plastic and e-waste recycling.
              <br />
              <a href="https://www.recycleindiafoundation.com" target="_blank" rel="noopener noreferrer">
                Visit Website
              </a>
            </li>
          </ul>
          <button style={styles.backButton} onClick={handleBackClick}>
          🔙 Back
        </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  wrapper: {
    backgroundColor: "#f4f7fb",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
  },
  card: {
    backgroundColor: "#fff",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
    maxWidth: "600px",
    width: "100%",
    textAlign: "left",
  },
  heading: {
    marginBottom: "20px",
    color: "#333",
    fontSize: "1.8rem",
    textAlign: "center",
  },
  section: {
    fontSize: "16px",
    lineHeight: "1.6",
  },
  list: {
    paddingLeft: "20px",
  },
};

export default NGOInitiative;
