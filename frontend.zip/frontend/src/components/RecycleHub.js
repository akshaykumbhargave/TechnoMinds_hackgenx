import React from 'react';

const RecycleHub = () => {
  return <h2>Welcome to RecycleHub</h2>;
};

export default RecycleHub;
