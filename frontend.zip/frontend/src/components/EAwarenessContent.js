import React from "react";
import { useNavigate } from "react-router-dom";

const EAwarenessContent = ({ title }) => {
  const navigate = useNavigate();

  const handleBackClick = () => {
    navigate(-1);
  };

  const renderContent = () => {
    if (title === "NGO Initiative") {
      // Navigate to the NGO Initiative page
      navigate("/ngo-initiative");
    }

    return <p>Details about {title} will be displayed here.</p>;
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={styles.heading}>{title}</h2>
        {renderContent()}
        <button style={styles.backButton} onClick={handleBackClick}>
          🔙 Back
        </button>
      </div>
    </div>
  );
};

const styles = {
  wrapper: {
    backgroundColor: "#f4f7fb",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
  },
  card: {
    backgroundColor: "#fff",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
    maxWidth: "600px",
    width: "100%",
    textAlign: "left",
  },
  heading: {
    marginBottom: "20px",
    color: "#333",
    fontSize: "1.8rem",
    textAlign: "center",
  },
  backButton: {
    marginTop: "30px",
    padding: "12px 24px",
    backgroundColor: "#00796b",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    fontSize: "16px",
    cursor: "pointer",
    display: "block",
    marginLeft: "auto",
    marginRight: "auto",
  },
};

export default EAwarenessContent;
