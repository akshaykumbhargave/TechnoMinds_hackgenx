import React from "react";
import { useNavigate, useLocation } from "react-router-dom";


const GovernmentPolicies = () => {
    const navigate = useNavigate();
      const location = useLocation();

      const handleBackClick = () => {
        navigate(-1);
      };
  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={styles.heading}>🏛️ Government Policies on E-Waste</h2>
        <p>Learn about the government’s initiatives and regulations related to e-waste management:</p>
        <ul style={styles.list}>
          <li style={styles.listItem}>
            <strong>National E-Waste Management Guidelines</strong>: The government has established guidelines to manage e-waste responsibly, aiming to reduce environmental pollution and promote recycling practices across the country.
          </li>
          <li style={styles.listItem}>
            <strong>E-Waste Legislation</strong>: Various laws, including the E-Waste (Management) Rules, mandate recycling and disposal of electronic waste by manufacturers and consumers.
          </li>
          <li style={styles.listItem}>
            <strong>Incentives for Recycling</strong>: Tax breaks, financial incentives, and reward programs for individuals and companies participating in e-waste recycling initiatives.
          </li>
          <li style={styles.listItem}>
            <strong>International Cooperation</strong>: The country is a signatory to the Basel Convention, working internationally to reduce the transboundary movement of hazardous e-waste.
          </li>
          <li style={styles.listItem}>
            <strong>Public Awareness Campaigns</strong>: Government-backed programs to educate the public about the environmental risks of e-waste and how to dispose of electronics safely.
          </li>
        </ul>
        <p style={styles.footer}>For more details, visit the official government website on e-waste management.</p>

        <button style={styles.backButton} onClick={handleBackClick}>
          🔙 Back
        </button>
      </div>
    </div>
  );
};

const styles = {
  wrapper: {
    backgroundColor: "#f4f7fb",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
  },
  card: {
    backgroundColor: "#fff",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
    maxWidth: "600px",
    width: "100%",
    textAlign: "center",
  },
  heading: {
    marginBottom: "20px",
    color: "#333",
    fontSize: "1.8rem",
  },
  list: {
    listStyleType: "none",
    padding: "0",
  },
  listItem: {
    cursor: "pointer",
    padding: "10px",
    margin: "10px 0",
    backgroundColor: "#f0f0f0",
    borderRadius: "8px",
    fontSize: "16px",
  },
  footer: {
    marginTop: "20px",
    color: "#777",
    fontSize: "14px",
  },
};

export default GovernmentPolicies;
