// RepairOption.js
import React, { useState } from "react";
import DisposalLocation from "./DisposalLocation";

const RepairOption = ({ onNext }) => {
  const [step, setStep] = useState(0);

  const nextStep = () => {
    setStep((prev) => prev + 1);
    onNext(); // Notify parent (RepairFlow) to proceed
  };

  const steps = [
    <DisposalLocation onNext={nextStep} />
  ];

  return <div>{steps[step]}</div>;
};

export default RepairOption;
