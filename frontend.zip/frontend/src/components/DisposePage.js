import React from "react";
import { useNavigate } from "react-router-dom";

const DisposePage = () => {
  const navigate = useNavigate();

  const goToLocationPage = () => {
    navigate("/disposal-location");
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.heading}>♻️ Ready to Dispose Responsibly?</h2>
        <p style={styles.subtext}>
          Find a nearby recycling hub to drop off your item and do your part for the planet. 🌍
        </p>
        <button style={styles.button} onClick={goToLocationPage}>
          🔍 Find Nearby Hubs
        </button>
      </div>
    </div>
  );
};

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f0f4f8",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  card: {
    backgroundColor: "#fff",
    padding: "40px 30px",
    borderRadius: "12px",
    boxShadow: "0 8px 20px rgba(0,0,0,0.1)",
    textAlign: "center",
    maxWidth: "500px",
  },
  heading: {
    fontSize: "24px",
    marginBottom: "15px",
    color: "#2c3e50",
  },
  subtext: {
    fontSize: "16px",
    color: "#555",
    marginBottom: "30px",
  },
  button: {
    padding: "14px 28px",
    fontSize: "16px",
    backgroundColor: "#1976d2",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "background-color 0.3s",
  },
  buttonHover: {
    backgroundColor: "#1565c0",
  },
};

export default DisposePage;
