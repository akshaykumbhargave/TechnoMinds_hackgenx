import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const DisposalLocation = () => {
  const [search, setSearch] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("Pimpri-Chinchwad");
  const [isLoading, setIsLoading] = useState(false);
  const [locationError, setLocationError] = useState(null);
  const [repairShops, setRepairShops] = useState([]);
  const [step, setStep] = useState(1); // 1: select location, 2: show hubs

  const navigate = useNavigate();
  const locationState = useLocation().state;

  useEffect(() => {
    if (locationState?.step === 2 && locationState.location) {
      setSelectedLocation(locationState.location);
      fetchRepairShops(locationState.location);
      setStep(2);
    }
  }, [locationState]);

  const fetchRepairShops = (location) => {
    const mockShops = [
      { name: "FixIt Repair Hub", location: `${location}, Street 1` },
      { name: "TechFix Hub", location: `${location}, Street 2` },
      { name: "QuickFix Hub", location: `${location}, Street 3` },
    ];
    setRepairShops(mockShops);
  };

  const handleSearchSubmit = () => {
    if (search.trim() !== "") setSelectedLocation(search);
  };

  const handleUseCurrentLocation = async () => {
    setIsLoading(true);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser.");
      setIsLoading(false);
      return;
    }

    try {
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 10000 });
      });
      setSearch("Detected Location");
      setSelectedLocation("Detected Location");
    } catch {
      setLocationError("Could not fetch location. Try again or enter manually.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleNext = () => {
    fetchRepairShops(selectedLocation);
    setStep(2);
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={styles.heading}>📍 Select Your Disposal Location</h2>

        {step === 1 && (
          <>
            <div style={styles.inputRow}>
              <input
                type="text"
                placeholder="Enter your location..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={styles.input}
              />
              <button onClick={handleSearchSubmit} style={styles.primaryButton}>Enter</button>
            </div>

            <div style={styles.orText}>OR</div>

            <button
              onClick={handleUseCurrentLocation}
              style={styles.secondaryButton}
              disabled={isLoading}
            >
              {isLoading ? "⌛ Detecting..." : "📡 Use Current Location"}
            </button>

            {locationError && <div style={styles.error}>{locationError}</div>}

            {selectedLocation && selectedLocation !== "Pimpri-Chinchwad" && (
              <div style={styles.locationBox}>
                <p>✅ Selected Location: <strong>{selectedLocation}</strong></p>
                <button onClick={handleNext} style={styles.continueButton}>Continue ➡️</button>
              </div>
            )}
          </>
        )}

        {step === 2 && (
          <div>
            <h3 style={styles.subheading}>Nearby Hubs in {selectedLocation}:</h3>
            {repairShops.map((shop, idx) => (
              <div key={idx} style={styles.hubCard}>
                <h4>{shop.name}</h4>
                <p>{shop.location}</p>
                <button
                  style={styles.primaryButton}
                  onClick={() => navigate("/hub-details", { state: shop })}
                >
                  Select This Hub
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  wrapper: {
    backgroundColor: "#f3f6f9",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
  },
  card: {
    backgroundColor: "#fff",
    padding: "40px",
    borderRadius: "16px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
    maxWidth: "600px",
    width: "100%",
  },
  heading: {
    textAlign: "center",
    marginBottom: "20px",
    color: "#2c3e50",
  },
  inputRow: {
    display: "flex",
    gap: "10px",
    marginBottom: "15px",
  },
  input: {
    flex: 1,
    padding: "12px",
    fontSize: "16px",
    borderRadius: "8px",
    border: "1px solid #ccc",
  },
  primaryButton: {
    backgroundColor: "#1976d2",
    color: "#fff",
    padding: "12px 18px",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
  },
  secondaryButton: {
    width: "100%",
    backgroundColor: "#4caf50",
    color: "#fff",
    padding: "12px",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    marginTop: "10px",
  },
  orText: {
    textAlign: "center",
    margin: "20px 0",
    fontSize: "1rem",
    color: "#666",
  },
  error: {
    color: "#d32f2f",
    backgroundColor: "#ffebee",
    padding: "10px",
    borderRadius: "8px",
    marginTop: "10px",
    textAlign: "center",
  },
  locationBox: {
    marginTop: "20px",
    padding: "15px",
    backgroundColor: "#e3f2fd",
    borderRadius: "8px",
    textAlign: "center",
  },
  continueButton: {
    marginTop: "10px",
    backgroundColor: "#00796b",
    color: "#fff",
    padding: "10px 20px",
    borderRadius: "8px",
    border: "none",
    cursor: "pointer",
  },
  subheading: {
    color: "#37474f",
    marginBottom: "15px",
  },
  hubCard: {
    backgroundColor: "#f0f0f0",
    padding: "15px 20px",
    borderRadius: "10px",
    marginBottom: "15px",
  },
};

export default DisposalLocation;
