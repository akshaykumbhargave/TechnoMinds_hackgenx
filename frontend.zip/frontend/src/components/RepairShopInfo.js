import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

const RepairShopInfo = () => {
  const { state } = useLocation();
  const navigate = useNavigate();

  if (!state) {
    return (
      <div style={styles.container}>
        <h2>No repair shop selected</h2>
        <button style={styles.backButton} onClick={() => navigate(-1)}>
          ⬅️ Go Back
        </button>
      </div>
    );
  }

  const { name, address, contact, hours } = state;

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Repair Shop Details</h2>
      <div style={styles.card}>
        <h3>{name}</h3>
        <p><strong>Address:</strong> {address}</p>
        <p><strong>Contact:</strong> {contact}</p>
        <p><strong>Working Hours:</strong> {hours}</p>
      </div>

      <button style={styles.backButton} onClick={() => navigate(-1)}>
        ⬅️ Back to Location Page
      </button>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "600px",
    margin: "0 auto",
    padding: "20px",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  heading: {
    fontSize: "1.5rem",
    marginBottom: "20px",
  },
  card: {
    backgroundColor: "#f5f5f5",
    padding: "20px",
    borderRadius: "10px",
    textAlign: "left",
    marginBottom: "30px",
  },
  backButton: {
    padding: "10px 20px",
    fontSize: "16px",
    backgroundColor: "#1976d2",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
  },
};

export default RepairShopInfo;
