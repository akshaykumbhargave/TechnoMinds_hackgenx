import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const HubInfoPage = () => {
  const [pickupConfirmed, setPickupConfirmed] = useState(false);
  const [redirectReady, setRedirectReady] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { hub, repairShop } = location.state || {};

  const handleConfirmPickup = () => {
    setPickupConfirmed(true);
    setRedirectReady(true);

    setTimeout(() => {
      setPickupConfirmed(false);
    }, 3000);
  };

  const handleGoToDashboard = () => {
    navigate("/dashboard");
  };

  const handleGoBack = () => {
    navigate("/nearby-shops");
  };
  

  return (
    <div style={styles.container}>
      <h2>🛠️ Nearby Repair Shop</h2>
      <div style={styles.hubDetails}>
        <h3>{repairShop?.name}</h3>
        <p><strong>Address:</strong> {repairShop?.address}</p>
        <p><strong>Contact:</strong> {repairShop?.contact}</p>
        <p><strong>Open Hours:</strong> {repairShop?.hours}</p>
      </div>

      {!redirectReady && (
        <div style={styles.buttonGroup}>
          {!pickupConfirmed && (
          <button
          onClick={handleGoBack}
            style={{
              ...styles.backButton,
              backgroundColor: "#e0e0e0",
              cursor: "pointer",
            }}
          >
            🔙 Back
          </button>
        )}


          <button style={styles.confirmButton} onClick={handleConfirmPickup}>
            ✅ Confirm RecycleHub
          </button>
        </div>
      )}

      {redirectReady && (
        <button style={styles.dashboardButton} onClick={handleGoToDashboard}>
          🚀 Go to Dashboard
        </button>
      )}

      {pickupConfirmed && (
        <div style={styles.popup}>
          📦 Pickup Confirmed! Thank you for recycling. 🌱
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    padding: "20px",
    textAlign: "center",
    fontFamily: "Arial, sans-serif",
  },
  hubDetails: {
    padding: "20px",
    backgroundColor: "#f1f1f1",
    borderRadius: "10px",
    marginBottom: "20px",
  },
  buttonGroup: {
    display: "flex",
    justifyContent: "center",
    gap: "15px",
  },
  backButton: {
    padding: "12px 20px",
    fontSize: "16px",
    backgroundColor: "#9e9e9e",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
  },
  confirmButton: {
    padding: "12px 20px",
    fontSize: "16px",
    backgroundColor: "#4caf50",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
  },
  dashboardButton: {
    padding: "12px 20px",
    fontSize: "16px",
    backgroundColor: "#2196f3",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
  },
  popup: {
    marginTop: "20px",
    padding: "12px",
    backgroundColor: "#d4edda",
    color: "#155724",
    borderRadius: "10px",
  },
};

export default HubInfoPage;
