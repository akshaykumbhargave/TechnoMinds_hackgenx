import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FaMapMarkerAlt, FaSearchLocation, FaLocationArrow, FaStore, FaArrowLeft } from "react-icons/fa";

const DisposalLocation = ({ onLocationSelect, onBack }) => {
  const [search, setSearch] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("Pimpri-Chinchwad");
  const [isLoading, setIsLoading] = useState(false);
  const [availability, setAvailability] = useState(null);
  const [showContinue, setShowContinue] = useState(false);
  const [networkError, setNetworkError] = useState(false);
  const [locationError, setLocationError] = useState(null);
  const [coordinates, setCoordinates] = useState(null);
  const [repairShops, setRepairShops] = useState([]);
  const [locationSelected, setLocationSelected] = useState(false);

  const navigate = useNavigate();

  const fetchRepairShops = (location) => {
    const mockShops = [
      {
        name: "FixIt Repair Shop",
        address: `${location}, Street 1`,
        contact: "+91 9988776655",
        hours: "10AM - 7PM",
      },
      {
        name: "TechFix Repair Center",
        address: `${location}, Street 2`,
        contact: "+91 9876543210",
        hours: "9AM - 6PM",
      },
      {
        name: "QuickFix Shop",
        address: `${location}, Street 3`,
        contact: "+91 9567894321",
        hours: "8AM - 5PM",
      },
    ];
    setRepairShops(mockShops);
  };

  const handleSearchSubmit = () => {
    if (search.trim() !== "") {
      setAvailability("available");
      setSelectedLocation(search);
      fetchRepairShops(search);
      setLocationSelected(true);
    }
  };

  const handleUseCurrentLocation = async () => {
    setIsLoading(true);
    setNetworkError(false);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser");
      setIsLoading(false);
      return;
    }

    try {
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          timeout: 10000,
        });
      });

      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      setCoordinates({ lat, lng });

      setSearch("Detected Location");
      setSelectedLocation("Detected Location");
      onLocationSelect && onLocationSelect("Detected Location");

      setAvailability("available");
      setLocationSelected(true);
      fetchRepairShops("Detected Location");
    } catch (error) {
      console.error("Location fetch failed:", error);
      const errorMessages = {
        1: "Location access was denied. Please enable location permissions.",
        2: "Location information is unavailable.",
        3: "The request to get your location timed out. Please try again.",
      };
      setLocationError(errorMessages[error.code] || "Unable to retrieve your location.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (search.trim() === "") return;
    const debounceTimer = setTimeout(() => {
      if (search !== selectedLocation) {
        setAvailability("available");
        setSelectedLocation(search);
        fetchRepairShops(search);
        setLocationSelected(true);
      }
    }, 500);
    return () => clearTimeout(debounceTimer);
  }, [search, selectedLocation]);

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}><FaStore /> Select a Pickup Location</h2>

      {!locationSelected ? (
        <>
          <div style={styles.locationCard}>
            <FaMapMarkerAlt style={styles.icon} />
            <strong>{selectedLocation}</strong>
            <span style={styles.badge}>Currently Selected</span>
          </div>

          <div style={styles.searchContainer}>
            <input
              type="text"
              placeholder="Search your location..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={styles.searchInput}
            />
            <button onClick={handleSearchSubmit} style={styles.searchButton}>
              <FaSearchLocation /> Enter
            </button>
          </div>

          <div style={styles.or}>— OR —</div>

          <button
            onClick={handleUseCurrentLocation}
            style={styles.locationButton}
            disabled={isLoading}
          >
            {isLoading ? "⌛ Detecting..." : <><FaLocationArrow /> Use Current Location</>}
          </button>

          {locationError && <div style={styles.alert}>{locationError}</div>}
        </>
      ) : (
        <div style={styles.shopList}>
          <h3 style={styles.shopHeader}>🔧 Nearby Repair Shops:</h3>
          {repairShops.map((shop, index) => (
            <div key={index} style={styles.shopCard}>
              <h4>{shop.name}</h4>
              <p>{shop.address}</p>
              <p>📞 {shop.contact}</p>
              <p>🕒 {shop.hours}</p>
              <button
                style={styles.selectButton}
                onClick={() => navigate("/hub-info", { state: { repairShop: shop, selectedLocation } })}


              >
                Select This Shop
              </button>
            </div>
          ))}
        </div>
      )}

      {networkError && <div style={styles.alert}>⚠️ Network error. Please try again later.</div>}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "700px",
    margin: "0 auto",
    padding: "30px",
    fontFamily: "'Segoe UI', sans-serif",
    color: "#333",
    background: "#fafafa",
    borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    transition: "all 0.3s ease-in-out",
  },
  heading: {
    fontSize: "1.8rem",
    textAlign: "center",
    marginBottom: "25px",
    color: "#2c3e50",
  },
  locationCard: {
    backgroundColor: "#e3f2fd",
    padding: "12px 20px",
    borderRadius: "8px",
    display: "flex",
    alignItems: "center",
    gap: "10px",
    justifyContent: "center",
    marginBottom: "20px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
  },
  icon: {
    color: "#1976d2",
    fontSize: "1.2rem",
  },
  badge: {
    backgroundColor: "#c8e6c9",
    padding: "5px 10px",
    borderRadius: "10px",
    fontSize: "0.8rem",
    color: "#388e3c",
  },
  searchContainer: {
    display: "flex",
    gap: "10px",
    marginBottom: "20px",
  },
  searchInput: {
    flex: 1,
    padding: "12px",
    fontSize: "16px",
    borderRadius: "6px",
    border: "2px solid #ccc",
  },
  searchButton: {
    backgroundColor: "#1976d2",
    color: "white",
    border: "none",
    padding: "12px 20px",
    borderRadius: "6px",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: "5px",
  },
  or: {
    textAlign: "center",
    margin: "20px 0",
    fontWeight: "bold",
    color: "#999",
  },
  locationButton: {
    backgroundColor: "#43a047",
    color: "white",
    border: "none",
    padding: "12px 20px",
    borderRadius: "6px",
    width: "100%",
    cursor: "pointer",
    fontWeight: "bold",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "8px",
  },
  alert: {
    marginTop: "15px",
    padding: "10px",
    backgroundColor: "#ffe0b2",
    color: "#e65100",
    borderRadius: "6px",
    textAlign: "center",
  },
  shopList: {
    marginTop: "25px",
  },
  shopHeader: {
    fontSize: "1.3rem",
    marginBottom: "10px",
  },
  shopCard: {
    backgroundColor: "#f5f5f5",
    padding: "15px",
    marginBottom: "15px",
    borderRadius: "8px",
    boxShadow: "0 2px 5px rgba(0,0,0,0.05)",
    transition: "transform 0.2s ease",
  },
  selectButton: {
    marginTop: "10px",
    padding: "10px 15px",
    backgroundColor: "#1976d2",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
  },
};

export default DisposalLocation;
