import React, { useState } from "react";
import "./Chatbot.css";

const faqData = [
  { question: "How to sign up", answer: "Go to the signup page and fill your details." },
  { question: "How to login", answer: "Enter your email and password on the login page." },
  { question: "How to request a pickup", answer: "Go to your dashboard and click on 'Request Pickup'." },
  { question: "How to contact support", answer: "You can email us at support@ecobot.com." },
  { question: "Where is my pickup status", answer: "Go to your profile > pickups to track the status." },
  { question: "How to upload license", answer: "If you're a shopkeeper, upload it during signup." },
  { question: "Can I change my role later", answer: "Currently, role change isn't supported post registration." },
  { question: "Where do I see my rewards", answer: "Visit the rewards section on your dashboard." },
  { question: "Is EcoBot eco-friendly", answer: "Yes! We help recycle and reduce e-waste responsibly." },
  { question: "What file types are allowed for license", answer: "JPEG, PNG and PDF files under 5MB." },
  { question: "How do I reset password", answer: "Click on 'Forgot Password' on the login page." },
  { question: "Why is my license not uploading", answer: "Check the file size and type, or try again later." },
  { question: "Is my data safe", answer: "Yes, we use encryption to protect your data." },
  { question: "Can I cancel a pickup", answer: "Yes, go to the pickup status and click 'Cancel'." },
  { question: "How can I earn more rewards", answer: "Refer friends and recycle more to earn rewards." },
  { question: "Is there a mobile app", answer: "Mobile app is under development and coming soon." },
  { question: "What cities are supported", answer: "Currently we operate in major metro cities." },
  { question: "How long does pickup take", answer: "Typically within 48 hours of request." },
  { question: "Can I recycle batteries", answer: "Yes, we accept small electronics and batteries." },
  { question: "Is there a fee for recycling", answer: "No, our services are free for users." },
  { question: "Hi", answer: "Hello! How can I assist you today?" },
  { question: "Hello", answer: "Hi there! Need help with something?" },
  { question: "Good morning", answer: "Good morning! Hope you're having a great day." },
  { question: "Good evening", answer: "Good evening! What would you like help with?" }
];

const Chatbot = () => {
  const [input, setInput] = useState("");
  const [chat, setChat] = useState([]);
  const [isOpen, setIsOpen] = useState(false);

  const getResponse = (inputText) => {
    const message = inputText.toLowerCase().trim();

    const matched = faqData.find((q) =>
      message.includes(q.question.toLowerCase())
    );

    if (matched) return matched.answer;

    return "Sorry, I didn't understand that. Please try asking something else.";
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const reply = getResponse(input);

    setChat([...chat, { user: input, bot: reply }]);
    setInput("");
  };

  return (
    <div className="chatbot-wrapper">
      {isOpen && (
        <div className="chatbot-container">
          <div className="chatbot-header">
            <h3>💬 EcoBot Support Assistant</h3>
            <button className="close-btn" onClick={() => setIsOpen(false)}>✖</button>
          </div>
          <div className="chatbox">
            {chat.map((c, i) => (
              <div key={i}>
                <p className="user-msg"><strong>You:</strong> {c.user}</p>
                <p className="bot-msg"><strong>Bot:</strong> {c.bot}</p>
              </div>
            ))}
          </div>
          <div className="chat-input">
            <input
              type="text"
              value={input}
              placeholder="Ask your question..."
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
            />
            <button onClick={handleSend}>Send</button>
          </div>
        </div>
      )}
      <button className="chat-icon" onClick={() => setIsOpen(!isOpen)}>
        💬
      </button>
    </div>
  );
};

export default Chatbot;
