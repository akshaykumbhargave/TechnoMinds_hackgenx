import React from "react";
import { useNavigate } from "react-router-dom";

const EAwareness = () => {
  const navigate = useNavigate();

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={styles.heading}>🌍 E-Awareness</h2>
        <p>Choose a topic to learn more:</p>
        <ul style={styles.list}>
          <li onClick={() => navigate("/ngo-initiative")} style={styles.listItem}>🤝 NGO Initiative</li>
          <li onClick={() => navigate("/government-policies")} style={styles.listItem}>🏛️ Government Policies</li>
        </ul>
      </div>
      
    </div>
  );
};

const styles = {
  wrapper: {
    backgroundColor: "#f4f7fb",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
  },
  card: {
    backgroundColor: "#fff",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
    maxWidth: "500px",
    width: "100%",
    textAlign: "center",
  },
  heading: {
    marginBottom: "20px",
    color: "#333",
    fontSize: "1.8rem",
  },
  list: {
    listStyleType: "none",
    padding: "0",
  },
  listItem: {
    cursor: "pointer",
    padding: "10px",
    margin: "10px 0",
    backgroundColor: "#f0f0f0",
    borderRadius: "8px",
    fontSize: "16px",
  },
};

export default EAwareness;
