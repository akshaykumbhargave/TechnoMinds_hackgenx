import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const HubDetailsPage = () => {
  const { state } = useLocation();
  const hub = state;
  const navigate = useNavigate();

  const [pickupConfirmed, setPickupConfirmed] = useState(false);
  const [redirectReady, setRedirectReady] = useState(false);

  const handleConfirmPickup = () => {
    setPickupConfirmed(true);
    setTimeout(() => {
      setRedirectReady(true);
    }, 2000);
  };

  const handleGoToDashboard = () => {
    navigate("/dashboard");
  };
  const handleBackToHubs = () => {
    navigate("/disposal-location", {
      state: { step: 2, location: hub.location },
    });
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={styles.heading}>📦 Recycle Hub Details</h2>

        <p><strong>🏷️ Name:</strong> {hub.name}</p>
        <p><strong>📍 Location:</strong> {hub.location}</p>

        {!redirectReady ? (
          <button style={styles.confirmButton} onClick={handleConfirmPickup}>
            ✅ Confirm RecycleHub
          </button>
        ) : (
          <button style={styles.dashboardButton} onClick={handleGoToDashboard}>
            🚀 Go to Dashboard
          </button>
        )}

        {pickupConfirmed && (
          <div style={styles.popup}>
            🎉 Pickup Confirmed! Thank you for recycling. 🌿
          </div>
        )}

        {/* Conditionally render the back button only when pickup is not confirmed */}
        {!pickupConfirmed && (
          <button
            onClick={handleBackToHubs}
            style={{
              ...styles.backButton,
              backgroundColor: "#e0e0e0",
              cursor: "pointer",
            }}
          >
            🔙 Back to Hubs
          </button>
        )}
      </div>
    </div>
  );
};

const styles = {
  wrapper: {
    backgroundColor: "#f4f7fb",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
  },
  card: {
    backgroundColor: "#fff",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
    maxWidth: "500px",
    width: "100%",
    textAlign: "center",
  },
  heading: {
    marginBottom: "20px",
    color: "#333",
    fontSize: "1.8rem",
  },
  confirmButton: {
    marginTop: "20px",
    padding: "12px 24px",
    backgroundColor: "#00796b",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    fontSize: "16px",
    cursor: "pointer",
  },
  dashboardButton: {
    marginTop: "20px",
    padding: "12px 24px",
    backgroundColor: "#1976d2",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    fontSize: "16px",
    cursor: "pointer",
  },
  popup: {
    marginTop: "20px",
    padding: "12px",
    backgroundColor: "#e8f5e9",
    color: "#2e7d32",
    borderRadius: "8px",
    fontWeight: "bold",
    fontSize: "15px",
  },
  backButton: {
    marginTop: "30px",
    backgroundColor: "#e0e0e0",
    color: "#333",
    padding: "10px 18px",
    borderRadius: "8px",
    fontSize: "14px",
    border: "none",
    cursor: "pointer",
  },
};

export default HubDetailsPage;
