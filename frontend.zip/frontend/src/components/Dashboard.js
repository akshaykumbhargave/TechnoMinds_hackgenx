import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Dashboard.css";

const Dashboard = () => {
  const navigate = useNavigate();
  
  const [showDropdown, setShowDropdown] = useState(false);
  const [showSubMenu, setShowSubMenu] = useState(false);
  const [showActivityOnly, setShowActivityOnly] = useState(false);
  const [showEAwarenessMenu, setShowEAwarenessMenu] = useState(false); // E-Awareness dropdown state

  const handleLogout = () => {
    // Clear authentication data from localStorage/sessionStorage
    localStorage.removeItem("user"); // Replace with your actual storage key
    localStorage.removeItem("token"); // Replace with your authentication token key
    sessionStorage.clear(); // Clear sessionStorage if used
    
    console.log("User logged out");

    // Navigate to the home page or login page
    navigate("/");  // Redirect to homepage or login page after logout
  };

  const handleMyActivityClick = () => {
    if (showSubMenu) {
      setShowSubMenu(false);
      setShowActivityOnly(false);
    } else {
      setShowSubMenu(true);
      setShowActivityOnly(true);
    }
  };

  const handleDropdownClick = () => {
    setShowDropdown(!showDropdown);
    if (!showDropdown) {
      setShowActivityOnly(false);
    }
  };

  const handleNextClick = () => {
    navigate("/diagnosis-result"); // Navigate to DiagnosisResult page
  };

  const handleEAwarenessClick = () => {
    setShowEAwarenessMenu(!showEAwarenessMenu); // Toggle E-Awareness dropdown visibility
  };

  return (
    <div className="dashboard">
      <header className="top-bar">
        <div className="left">
          <div className="logo-container">
            <span className="logo-icon">🌿</span>
            <div className="logo-text">
              <h1 className="ecobot">EcoBot</h1>
              <p className="tagline">Smart E-Waste Management</p>
            </div>
          </div>
        </div>

        <div className="right">
          <div className="notification" title="Notifications">🔔</div>
          <div className="applications">
            <button className="app-button" onClick={handleDropdownClick}>
              📋 My Account
            </button>

            {showDropdown && (
              <div className="dropdown">
                <ul>
                  <li
                    className="nested"
                    onClick={handleMyActivityClick}
                    style={{ cursor: "pointer" }}
                  >
                    📋 My Activity {showSubMenu ? "▲" : "▾"}
                    {showSubMenu && (
                      <ul className="sub-dropdown">
                        <li onClick={() => navigate("/diagnosis-report")} style={{ cursor: "pointer" }}>
                          🛠️ Repair
                        </li>
                        <li onClick={() => navigate("/disposalRecyclehub")} style={{ cursor: "pointer" }}>
                          🗑️ Dispose
                        </li>
                      </ul>
                    )}
                  </li>

                  {!showActivityOnly && (
                    <>
                      <li><Link to="/rewards">🏆 Rewards</Link></li>
                    </>
                  )}

                  {/* E-Awareness section with dropdown toggle */}
                  <li
                    className="nested"
                    onClick={handleEAwarenessClick}
                    style={{ cursor: "pointer" }}
                  >
                    🌍 E-Awareness {showEAwarenessMenu ? "▲" : "▾"}
                    {showEAwarenessMenu && (
                      <ul className="sub-dropdown">
                        <li onClick={() => navigate("/ngo-initiative")} style={{ cursor: "pointer" }}>
                          🤝 NGO Initiative
                        </li>
                        <li onClick={() => navigate("/government-policies")} style={{ cursor: "pointer" }}>
                          🏛️ Government Policies
                        </li>
                      </ul>
                    )}
                  </li>

                  {/* Move Logout button below E-Awareness */}
                  <li onClick={handleLogout} style={{ cursor: "pointer" }}>
                    🚪 Logout
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="main-content">
        <div className="glass-card">
          <div className="card-content">
            {/* Your existing card content */}
          </div>
        </div>

        {/* Next button that navigates to DiagnosisResult */}
        <div className="next-button-container">
          <button className="next-button" onClick={handleNextClick}>
            Next
          </button>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
 