import axios from "axios";

const instance = axios.create({
  baseURL: "http://localhost:5000/api", // Don't add `/api` if your Flask routes don't use it
  headers: {
    "Content-Type": "application/json",
  },
});

export default instance;
