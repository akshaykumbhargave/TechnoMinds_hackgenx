import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';

import HomePage from './components/HomePage';
import WelcomePage from './components/WelcomePage';
import Login from './components/Login';
import SignUp from './components/Signup';
import Dashboard from './components/Dashboard';
import Emart from './components/Emart';
import RecycleHub from './components/RecycleHub';
import Logout from './components/Logout';
import Chatbot from './components/Chatbot';

import DisposalOption from "./components/DisposalOption";
import RepairOption from "./components/RepairOption";
import FixEwaste from "./components/FixEwaste";
import TransportAgent from "./components/TransportAgent";
import EarnReward from "./components/EarnReward";
import DisposalNearbyHubs from "./components/DisposalNearbyHubs";
import DiagnosisReport from "./components/DiagnosisReport";
import DisposalLocation from "./components/DisposalLocation";
import DiagnosisResult from "./components/DiagnosisResult";
import HubInfoPage from "./components/HubInfoPage";
import RepairShopInfo from "./components/RepairShopInfo";
import DisposePage from "./components/DisposePage";
import DisposalLocationPage from "./components/DisposalLocationPage";
import HubDetailsPage from "./components/HubDetailsPage";
import EAwareness from "./components/EAwareness";
import EAwarenessContent from "./components/EAwarenessContent";
import NGOInitiative from "./components/NGOInitiative";
import GovernmentPolicies from "./components/GovernmentPolicies";

import './App.css';

// Repair Flow Component
function RepairFlow() {
  const [step, setStep] = useState(0);
  const handleNext = () => setStep((prev) => prev + 1);

  switch (step) {
    case 0: return <DisposalLocation onNext={handleNext} />;
    case 1: return <DisposalNearbyHubs onNext={handleNext} />;
    case 2: return <RepairOption onNext={handleNext} />;
    case 3: return <FixEwaste onNext={handleNext} />;
    case 4: return <TransportAgent onNext={handleNext} />;
    case 5: return <RecycleHub onNext={handleNext} />;
    case 6: return <EarnReward />;
    default: return <Navigate to="/" />;
  }
}

function AppWrapper() {
  const navigate = useNavigate();

  const handleDecision = (decision) => {
    if (decision === "repair") {
      navigate("/repair");
    } else if (decision === "disposal") {
      navigate("/disposalLocation");
    }
  };

  return (
    <>
      <Routes>
        {/* General Website Routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/welcome" element={<WelcomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/logout" element={<Logout />} />

        {/* Repair & Disposal Flow Routes */}
        <Route path="/repair" element={<RepairFlow />} />
        <Route path="/location" element={<DisposalLocation />} />
        <Route path="/repair-shop-info" element={<RepairShopInfo />} />
        <Route path="/dispose" element={<DisposalOption />} />
        <Route path="/hub-info" element={<HubInfoPage />} />
        <Route path="/rewards" element={<EarnReward />} />
        <Route path="/disposalRecyclehub" element={<DisposalNearbyHubs />} />
        <Route path="/recyclehub" element={<RecycleHub />} />
        <Route path="/diagnosis-report" element={<DiagnosisReport />} />
        <Route path="/diagnosis-result" element={<DiagnosisResult onDecision={handleDecision} />} />
        <Route path="/disposalLocation" element={<DisposePage />} />
        <Route path="/disposal-location" element={<DisposalLocationPage />} />
        <Route path="/hub-details" element={<HubDetailsPage />} />
        <Route path="/nearby-shops" element={<DisposalLocation />} />

        {/* Extra Pages */}
        <Route path="/emart" element={<Emart />} />
        <Route path="/eawareness" element={<EAwarenessContent />} />
        <Route path="/ngo-initiative" element={<NGOInitiative />} />
        <Route path="/government-policies" element={<GovernmentPolicies />} />

        {/* 404 Route */}
        <Route
          path="*"
          element={
            <div style={{ padding: "2rem", textAlign: "center" }}>
              <h2>404 - Page Not Found</h2>
              <p>
                Go back to{" "}
                <a href="/" style={{ color: "#10b981", textDecoration: "none" }}>
                  EcoBot Dashboard
                </a>
              </p>
            </div>
          }
        />
      </Routes>

      {/* Chatbot visible on all pages */}
      <Chatbot />
    </>
  );
}

// Main App with Router
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/welcome" element={<WelcomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
